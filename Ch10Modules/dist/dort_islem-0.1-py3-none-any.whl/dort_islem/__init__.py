
from  .toplama import topla
from .cikarma import cikar
from .carpma import carp
from .bolme import bol